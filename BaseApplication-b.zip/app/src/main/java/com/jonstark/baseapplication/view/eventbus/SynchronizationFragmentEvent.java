package com.jonstark.baseapplication.view.eventbus;

public class SynchronizationFragmentEvent {
    private int EventID;
    private Object EventData;

    public SynchronizationFragmentEvent(int eventID, Object eventData) {
        EventID = eventID;
        EventData = eventData;
    }

    public int getEventID() {
        return EventID;
    }

    public void setEventID(int eventID) {
        EventID = eventID;
    }

    public Object getEventData() {
        return EventData;
    }

    public void setEventData(Object eventData) {
        EventData = eventData;
    }
}
