package com.jonstark.baseapplication.viewmodel.fragment;
import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.util.Log;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.database.BaseApplicationDatabase;
import com.jonstark.baseapplication.service.database.daoobject.BatchDao;
import com.jonstark.baseapplication.service.database.daoobject.CustomerDao;
import com.jonstark.baseapplication.service.database.daoobject.InvoiceDao;
import com.jonstark.baseapplication.service.entities.Batch;
import com.jonstark.baseapplication.service.entities.Customer;
import com.jonstark.baseapplication.service.entities.Invoice;
import com.jonstark.baseapplication.service.webservice.BaseApplicationWebservice;
import com.jonstark.baseapplication.view.eventbus.EventID;
import com.jonstark.baseapplication.view.eventbus.SynchronizationFragmentEvent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SharedViewModel extends ViewModel {
    private static final String TAG = "SHARED VIEW MODEL";

    //Room data access object
    private CustomerDao customerDao;
    private BatchDao batchDao;
    private InvoiceDao invoiceDao;

    //Live data from database
    private MediatorLiveData<List<Customer>> customerList;
    private MediatorLiveData<List<Batch>> batchList;

    //Webservice
    private BaseApplicationWebservice api;

    //Application context
    private Application application;

    //Shared preferences
    private SharedPreferences sharedPreferences;

    private EventBus eventBus;
    @Inject
    public SharedViewModel(BaseApplicationDatabase database, BaseApplicationWebservice webservice, Application application, EventBus eventBus){
        //Listen to EventBus post event
        eventBus.register(this);
        this.api = webservice;
        this.eventBus = eventBus;
        this.customerDao = database.customerDao();
        this.batchDao =  database.batchDao();
        this.invoiceDao = database.invoiceDao();
        this.application = application;
        this.sharedPreferences = application.getSharedPreferences(
                application.getResources().getString(R.string.share_preferences), Context.MODE_PRIVATE);
        //using mediator live data to observe data change from database
        initCustomerList();
        initBatchList();


    }
    public LiveData<List<Customer>> getCustomers(){
        return customerList;
    }
    public LiveData<List<Batch>> getBatches(){
        return batchList;
    }
    private void initCustomerList(){
        customerList = new MediatorLiveData<>();
        customerList.addSource(customerDao.getAllCustomer(), new android.arch.lifecycle.Observer<List<Customer>>() {
            @Override
            public void onChanged(@Nullable List<Customer> customers) {
                customerList.setValue(customers);
            }
        });
    }
    private void initBatchList(){
        batchList = new MediatorLiveData<>();
        batchList.addSource(batchDao.getBatches(), new Observer<List<Batch>>() {
            @Override
            public void onChanged(@Nullable List<Batch> batches) {
                batchList.setValue(batches);
            }
        });
    }
    private void getBatchFromWebservice(){
        api.getBatchs(sharedPreferences.getString(
                application.getResources().getString(R.string.userCodeKey), ""))
                .enqueue(new Callback<List<Batch>>() {
                    @Override
                    public void onResponse(Call<List<Batch>> call, Response<List<Batch>> response) {
                        final Response<List<Batch>> res = response;
                        if(response.body() != null){
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    batchDao.addBatch(res.body());
                                }
                            }).start();
                        }
                    }
                    @Override
                    public void onFailure(Call<List<Batch>> call, Throwable t) {
                        Log.e(TAG, t.getMessage());
                        eventBus.post(new SynchronizationFragmentEvent(EventID.DOWNLOAD_DATA_ERROR, null));
                    }
                });
    }
    private void downloadCustomersAtBatchIndex(final int index){
        int id = batchList.getValue().get(index).getCode();
        api.getCustomers(sharedPreferences.getString(
                application.getResources().getString(R.string.userCodeKey), ""), id)
                .enqueue(new Callback<List<Customer>>() {
                    @Override
                    public void onResponse(Call<List<Customer>> call, Response<List<Customer>> response) {
                        final List<Customer> customers = response.body();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    customerDao.addCustomers(customers);
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                                //download invoices after download customer
                                downloadInvoicesAtBatchIndex(index);
                            }
                        }).start();
                    }
                    @Override
                    public void onFailure(Call<List<Customer>> call, Throwable t) {
                        Log.e(TAG, t.getMessage());
                        eventBus.post(new SynchronizationFragmentEvent(EventID.DOWNLOAD_DATA_ERROR, null));
                    }
                });
    }
    private void downloadInvoicesAtBatchIndex(int index){
        int id = batchList.getValue().get(index).getCode();
        api.getInvoices(sharedPreferences.getString(
                application.getResources().getString(R.string.userCodeKey), ""), id)
                .enqueue(new Callback<List<Invoice>>() {
                    @Override
                    public void onResponse(Call<List<Invoice>> call, Response<List<Invoice>> response) {
                        final List<Invoice> invoices = response.body();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try{
                                    invoiceDao.addInvoices(invoices);
                                }catch (Exception e){
                                    e.printStackTrace();
                                }
                                eventBus.post(new SynchronizationFragmentEvent(EventID.DONWLOAD_DATA_COMPLETE, null));
                            }
                        }).start();
                    }

                    @Override
                    public void onFailure(Call<List<Invoice>> call, Throwable t) {
                        Log.e(TAG, t.getMessage());
                        eventBus.post(new SynchronizationFragmentEvent(EventID.DOWNLOAD_DATA_ERROR, null));
                    }
                });
    }

    @Subscribe(threadMode = ThreadMode.ASYNC)
    public void onSynchronizationFragmentEvent(SynchronizationFragmentEvent event){
        switch (event.getEventID()){
            case EventID.ACTION_SYNC:{
                getBatchFromWebservice();
                break;
            }
            case EventID.DOWNLOAD_DATA_AT_BATCH:{
                downloadCustomersAtBatchIndex((int)event.getEventData());
                break;
            }
        }
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        //Unregister EventBus event
        eventBus.unregister(this);
        Log.d(TAG, "cleared");
    }
}
