package com.jonstark.baseapplication.service.database.daoobject;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.jonstark.baseapplication.service.entities.Invoice;

import java.util.List;

@Dao
public interface InvoiceDao {
    @Query("select * from invoice")
    LiveData<List<Invoice>> getInvoices();
    @Insert
    void addInvoices(List<Invoice> invoices);
}
