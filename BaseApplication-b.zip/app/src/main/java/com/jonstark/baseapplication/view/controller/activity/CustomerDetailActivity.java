package com.jonstark.baseapplication.view.controller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.TextView;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Customer;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CustomerDetailActivity extends AppCompatActivity {

    @BindView(R.id.edCustomerName)
    public TextView edCustomerName;
    @BindView(R.id.edCustomerCode)
    public TextView edCustomerCode;
    @BindView(R.id.edCustomerPhone)
    public EditText edCustomerPhone;
    @BindView(R.id.edCustomerBankName)
    public EditText edCustomerBankName;
    @BindView(R.id.edCustomerBankNumber)
    public EditText edCustomerBankNumber;
    @BindView(R.id.edCustomerTaxCode)
    public EditText edCustomerTaxCode;
    @BindView(R.id.edCustomerAddress)
    public EditText edCustomerAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        Customer customer = (Customer) intent.getSerializableExtra("customer");
        edCustomerName.setText(customer.getFullName().trim());
        edCustomerCode.setText(customer.getId());
        edCustomerPhone.setText(customer.getPhoneNumber());
        edCustomerTaxCode.setText(customer.getTaxCode());
        edCustomerAddress.setText(customer.getAddress());
    }
}
