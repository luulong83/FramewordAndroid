package com.jonstark.baseapplication.di;

import android.app.Application;

import com.jonstark.baseapplication.BaseApplication;

import javax.inject.Singleton;

import dagger.BindsInstance;
import dagger.Component;
import dagger.android.AndroidInjectionModule;
import dagger.android.support.AndroidSupportInjectionModule;

@Singleton
@Component(modules = {
        BaseApplicationModule.class,
        AndroidInjectionModule.class,
        AndroidSupportInjectionModule.class,
        ActivityBuilder.class
})
public interface BaseApplicationComponent {

    @Component.Builder
    interface Builder{
        @BindsInstance
        Builder application(Application application);
        BaseApplicationComponent build();
    }

    void inject(BaseApplication application);
}
