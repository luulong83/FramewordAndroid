package com.jonstark.baseapplication.view.eventbus;

public class EventID {
    public static final int ACTION_SYNC = 0;
    public static final int DOWNLOAD_DATA_AT_BATCH = 1;
    public static final int DONWLOAD_DATA_COMPLETE = 2;
    public static final int DOWNLOAD_DATA_ERROR = 3;
}
