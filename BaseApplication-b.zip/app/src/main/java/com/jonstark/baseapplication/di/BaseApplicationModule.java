package com.jonstark.baseapplication.di;

import android.app.Application;
import android.arch.persistence.room.Room;
import android.content.Context;

import com.jonstark.baseapplication.di.subcomponent.MainActivityViewModelsBuilder;
import com.jonstark.baseapplication.service.database.BaseApplicationDatabase;

import org.greenrobot.eventbus.EventBus;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module(includes = {NetworkModule.class})
public class BaseApplicationModule {

    @Provides
    @Singleton
    public BaseApplicationDatabase appDatabase(Application application){
        return Room.databaseBuilder(application, BaseApplicationDatabase.class, "app_database").build();
    }

    @Provides
    public EventBus eventBus(){
        return EventBus.getDefault();
    }
}
