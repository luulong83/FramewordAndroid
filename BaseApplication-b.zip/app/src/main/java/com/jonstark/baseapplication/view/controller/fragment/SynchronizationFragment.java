package com.jonstark.baseapplication.view.controller.fragment;

import android.app.Dialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Dao;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Batch;
import com.jonstark.baseapplication.service.entities.Customer;
import com.jonstark.baseapplication.utils.DialogUtils;
import com.jonstark.baseapplication.view.adapter.ListBatchAdapter;
import com.jonstark.baseapplication.view.eventbus.EventID;
import com.jonstark.baseapplication.view.eventbus.SynchronizationFragmentEvent;
import com.jonstark.baseapplication.viewmodel.ViewModelFactory;
import com.jonstark.baseapplication.viewmodel.fragment.SharedViewModel;

import org.angmarch.views.NiceSpinner;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;

public class SynchronizationFragment extends Fragment {
    private static final String TAG = "SYNC_FRAGMENT";
    @BindView(R.id.spnMonth)
    public NiceSpinner spnMonth;
    @BindView(R.id.rcBatch)
    public RecyclerView rcBatches;
    private List<String> arr;
    private ListBatchAdapter adapter;

    @Inject
    public EventBus eventBus;
    @Inject
    public ViewModelFactory factory;
    private SharedViewModel viewModel;
    private Dialog loadingDialog;


    @Inject
    public SynchronizationFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        loadingDialog = DialogUtils.createLoadingDialog(getActivity());
        arr = new ArrayList<>();
        arr.add("02/2018");
        arr.add("03/2018");
        arr.add("04/2018");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root =  inflater.inflate(R.layout.fragment_synchronization, container, false);
        ButterKnife.bind(this, root);
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        spnMonth.attachDataSource(arr);
        AndroidSupportInjection.inject(this);
        eventBus.register(this);
        viewModel = ViewModelProviders.of(Objects.requireNonNull(getActivity()), factory).get(SharedViewModel.class);
        viewModel.getBatches().observe(getActivity(), new Observer<List<Batch>>() {
            @Override
            public void onChanged(@Nullable List<Batch> batches) {
                adapter = new ListBatchAdapter(batches, getContext(), new ListBatchAdapter.ListBatchItemActionListener() {
                    @Override
                    public void onDownloadButtonClickedAtPosition(int position) {
                        loadingDialog.show();
                        eventBus.post(new SynchronizationFragmentEvent(EventID.DOWNLOAD_DATA_AT_BATCH, position));
                        Log.d(TAG, "Down load data from batch : " + position);
                    }
                });
                rcBatches.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
                rcBatches.setLayoutManager(new LinearLayoutManager(getActivity()));
                rcBatches.setAdapter(adapter);
                if(loadingDialog != null){
                    if(loadingDialog.isShowing()){
                        loadingDialog.dismiss();
                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_sync) {
            loadingDialog.show();
            eventBus.post(new SynchronizationFragmentEvent(EventID.ACTION_SYNC, null));
        }
        return super.onOptionsItemSelected(item);
    }

    @Subscribe(threadMode = ThreadMode.ASYNC)
    public void onSynchronizationFragmentEvent(SynchronizationFragmentEvent event){
        switch (event.getEventID()){
            case EventID.DONWLOAD_DATA_COMPLETE:{
                if(loadingDialog != null){
                    if(loadingDialog.isShowing()){
                        loadingDialog.dismiss();
                    }
                }
                break;
            }

            case EventID.DOWNLOAD_DATA_ERROR:{
                if(loadingDialog != null){
                    if(loadingDialog.isShowing()){
                        loadingDialog.dismiss();
                    }
                }
                //show download error dialog
                break;
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        eventBus.unregister(this);
    }
}
