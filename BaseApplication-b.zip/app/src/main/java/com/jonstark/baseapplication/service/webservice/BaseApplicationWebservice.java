package com.jonstark.baseapplication.service.webservice;

import com.jonstark.baseapplication.service.entities.Batch;
import com.jonstark.baseapplication.service.entities.Customer;
import com.jonstark.baseapplication.service.entities.Employee;
import com.jonstark.baseapplication.service.entities.Invoice;
import com.jonstark.baseapplication.service.entities.InvoiceResult;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BaseApplicationWebservice {
    @GET("admin/GetEmployee")
    Call<Employee> employeeLogin(@Query("userName") String userName, @Query("password") String password);
    @GET("danhmuc/Get_DSDot")
    Call<List<Batch>> getBatchs(@Query("maNhanVien") String staffCode);
    @GET("danhmuc/Get_DSKhachHang")
    Call<List<Customer>> getCustomers(@Query("maNhanVien") String staffCode, @Query("dot") int batch);
    @GET("danhmuc/Get_DSHoaDon")
    Call<List<Invoice>> getInvoices(@Query("maNhanVien") String staffCode,@Query("dot") int batch);
    @GET("hoadon/Get_KiemTraThanhToanHoaDon")
    Call<List<InvoiceResult>> checkInvoices(@Query("maNhanVien") String staffCode, @Query("arrHoaDon") String invoices);
}
