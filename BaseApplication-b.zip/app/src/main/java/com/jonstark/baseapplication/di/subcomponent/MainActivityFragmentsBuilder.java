package com.jonstark.baseapplication.di.subcomponent;

import com.jonstark.baseapplication.view.controller.fragment.AccountSettingFragment;
import com.jonstark.baseapplication.view.controller.fragment.CustomerFragment;
import com.jonstark.baseapplication.view.controller.fragment.FirstFragment;
import com.jonstark.baseapplication.view.controller.fragment.InvoiceFragment;
import com.jonstark.baseapplication.view.controller.fragment.SecondFragment;
import com.jonstark.baseapplication.view.controller.fragment.SynchronizationFragment;
import com.jonstark.baseapplication.view.controller.fragment.ThirdFragment;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class MainActivityFragmentsBuilder {
    @ContributesAndroidInjector
    abstract FirstFragment firstFragment();
    @ContributesAndroidInjector
    abstract SecondFragment secondFragment();
    @ContributesAndroidInjector
    abstract ThirdFragment thirdFragment();
    @ContributesAndroidInjector
    abstract AccountSettingFragment accountSettingFragment();
    @ContributesAndroidInjector
    abstract InvoiceFragment invoiceFragment();
    @ContributesAndroidInjector
    abstract CustomerFragment customerFragment();
    @ContributesAndroidInjector
    abstract SynchronizationFragment synchronizationFragment();
}
