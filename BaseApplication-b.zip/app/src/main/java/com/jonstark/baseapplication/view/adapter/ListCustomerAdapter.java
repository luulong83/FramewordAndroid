package com.jonstark.baseapplication.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Customer;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ListCustomerAdapter extends RecyclerView.Adapter<ListCustomerAdapter.ViewHolder>{

    private List<Customer> customers;
    private Context context;
    private ListCustomerItemActionListener callback;
    public ListCustomerAdapter(List<Customer> customers, Context context, ListCustomerItemActionListener listener){
        this.customers = customers;
        this.context = context;
        this.callback = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.customer_list_item, parent, false);
        return new ViewHolder(root);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final int pos = position;
        Customer customer = customers.get(position);
        String sortName = customer.getFullName().substring(0,2);
        holder.tvSortName.setText(sortName);
        holder.tvCustomerCode.setText(customer.getId());
        holder.tvCustomerName.setText(customer.getFullName());
        holder.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.onItemSelectedAtIndex(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return customers.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.tvSortName)
        public TextView tvSortName;
        @BindView(R.id.tvCustomerCode)
        public TextView tvCustomerCode;
        @BindView(R.id.tvCustomerName)
        public TextView tvCustomerName;
        public View row;

        public ViewHolder(View itemView) {
            super(itemView);
            this.row = itemView;
            ButterKnife.bind(this, itemView);
        }
    }

    public interface ListCustomerItemActionListener{
        void onItemSelectedAtIndex(int index);
    }
}
