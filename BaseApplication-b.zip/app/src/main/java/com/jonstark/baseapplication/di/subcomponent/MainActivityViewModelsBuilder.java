package com.jonstark.baseapplication.di.subcomponent;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;

import com.jonstark.baseapplication.di.mapkey.ViewModelKey;
import com.jonstark.baseapplication.viewmodel.ViewModelFactory;
import com.jonstark.baseapplication.viewmodel.activity.MainActivityViewModel;
import com.jonstark.baseapplication.viewmodel.fragment.SharedViewModel;

import dagger.Binds;
import dagger.Module;
import dagger.multibindings.IntoMap;

@Module
public abstract class MainActivityViewModelsBuilder {
    @Binds
    @IntoMap
    @ViewModelKey(SharedViewModel.class)
    abstract ViewModel sharedViewModel(SharedViewModel sharedViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(MainActivityViewModel.class)
    abstract ViewModel mainActivityViewModel(MainActivityViewModel mainActivityViewModel);

    @Binds
    abstract ViewModelProvider.Factory factory(ViewModelFactory viewModelFactory);
}
