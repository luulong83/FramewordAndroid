package com.jonstark.baseapplication.service.database.daoobject;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.jonstark.baseapplication.service.entities.Batch;

import java.util.List;

@Dao
public interface BatchDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addBatch(List<Batch> batches);
    @Query("select * from batch")
    LiveData<List<Batch>> getBatches();
}
