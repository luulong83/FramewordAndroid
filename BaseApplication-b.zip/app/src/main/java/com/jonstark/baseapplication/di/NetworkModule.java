package com.jonstark.baseapplication.di;

import com.jonstark.baseapplication.service.webservice.BaseApplicationWebservice;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
public class NetworkModule {
    private static final String BASE_URL = "http://118.69.70.159:8081/api/";
    @Provides
    @Singleton
    public Retrofit getRetrofit(){
        return new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    @Provides
    @Singleton
    public BaseApplicationWebservice getAPI(Retrofit retrofit){
        return retrofit.create(BaseApplicationWebservice.class);
    }
}
