package com.jonstark.baseapplication.service.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

@Entity
public class Invoice {
    @NonNull
    @PrimaryKey
    @SerializedName("so_hd")
    private String Id;
    @SerializedName("ma_kh")
    private String CustomerCode;
    @SerializedName("ten_kh")
    private String CustomerName;
    @SerializedName("dia_chi")
    private String Address;
    @SerializedName("thang_ps")
    private String Month;
    @SerializedName("ma_tuyen_cuoc")
    private String RouteCode;
    @SerializedName("tu_ngay")
    private String FromDate;
    @SerializedName("den_ngay")
    private String ToDate;
    @SerializedName("ma_dot")
    private int Batch;
    @SerializedName("code")
    private String Code;
    @SerializedName("so_bo")
    private String DepBook;
    @SerializedName("cs_cu")
    private int OldNumber;
    @SerializedName("cs_moi")
    private int NewNumber;
    @SerializedName("m3tt")
    private int Volume;

    //Vietnamese required field
    @SerializedName("dinh_muc")
    private int DinhMuc;
    @SerializedName("gia_bieu")
    private int GiaBieu;
    @SerializedName("tienpbvmt")
    private int PhiBvmt;
    @SerializedName("tien_hang")
    private int TienHang;
    @SerializedName("tien_thue")
    private int TienThue;
    @SerializedName("tong_tien")
    private int TongTien;

    @NonNull
    public String getId() {
        return Id;
    }

    public void setId(@NonNull String id) {
        Id = id;
    }

    public String getCustomerCode() {
        return CustomerCode;
    }

    public void setCustomerCode(String customerCode) {
        CustomerCode = customerCode;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String month) {
        Month = month;
    }

    public String getRouteCode() {
        return RouteCode;
    }

    public void setRouteCode(String routeCode) {
        RouteCode = routeCode;
    }

    public String getFromDate() {
        return FromDate;
    }

    public void setFromDate(String fromDate) {
        FromDate = fromDate;
    }

    public String getToDate() {
        return ToDate;
    }

    public void setToDate(String toDate) {
        ToDate = toDate;
    }

    public int getBatch() {
        return Batch;
    }

    public void setBatch(int batch) {
        Batch = batch;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getDepBook() {
        return DepBook;
    }

    public void setDepBook(String depBook) {
        DepBook = depBook;
    }

    public int getOldNumber() {
        return OldNumber;
    }

    public void setOldNumber(int oldNumber) {
        OldNumber = oldNumber;
    }

    public int getNewNumber() {
        return NewNumber;
    }

    public void setNewNumber(int newNumber) {
        NewNumber = newNumber;
    }

    public int getVolume() {
        return Volume;
    }

    public void setVolume(int volume) {
        Volume = volume;
    }

    public int getDinhMuc() {
        return DinhMuc;
    }

    public void setDinhMuc(int dinhMuc) {
        DinhMuc = dinhMuc;
    }

    public int getGiaBieu() {
        return GiaBieu;
    }

    public void setGiaBieu(int giaBieu) {
        GiaBieu = giaBieu;
    }

    public int getPhiBvmt() {
        return PhiBvmt;
    }

    public void setPhiBvmt(int phiBvmt) {
        PhiBvmt = phiBvmt;
    }

    public int getTienHang() {
        return TienHang;
    }

    public void setTienHang(int tienHang) {
        TienHang = tienHang;
    }

    public int getTienThue() {
        return TienThue;
    }

    public void setTienThue(int tienThue) {
        TienThue = tienThue;
    }

    public int getTongTien() {
        return TongTien;
    }

    public void setTongTien(int tongTien) {
        TongTien = tongTien;
    }
}
