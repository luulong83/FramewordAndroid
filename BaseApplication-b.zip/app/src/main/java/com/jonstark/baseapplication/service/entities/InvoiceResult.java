package com.jonstark.baseapplication.service.entities;

public class InvoiceResult {
    private String Id;
    private int Result;

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public int getResult() {
        return Result;
    }

    public void setResult(int result) {
        Result = result;
    }
}
