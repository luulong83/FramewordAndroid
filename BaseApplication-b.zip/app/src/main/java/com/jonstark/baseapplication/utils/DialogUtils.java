package com.jonstark.baseapplication.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Employee;
import com.jonstark.baseapplication.view.controller.activity.LoginActivity;

public class DialogUtils {
    public static Dialog createExitApplicationDialog(final Activity context){
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.exit_app_dialog);
        final Button btnAccept = dialog.findViewById(R.id.btnAccept);
        final Button btnCancel = dialog.findViewById(R.id.btnCancel);
        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                context.finish();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        return dialog;
    }

    public static Dialog createLoginConfirmDialog(final Activity context, String name){
        final Dialog dialog = new Dialog(context);
        final LoginActivity loginActivity = (LoginActivity) context;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.confirm_login_dialog);
        dialog.setCancelable(false);
        final TextView tvUsername = dialog.findViewById(R.id.tvUsername);
        final Button btnContinue = dialog.findViewById(R.id.btnContinue);
        final Button btnOtherAccount = dialog.findViewById(R.id.btnOtherAccount);
        tvUsername.setText(name);
        btnOtherAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginActivity.clearLoginConfiguration();
                dialog.dismiss();
            }
        });
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginActivity.gotoMainActivity();
                context.finish();
                dialog.dismiss();
            }
        });
        return dialog;
    }

    public static Dialog createLoadingDialog(final Activity context){
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.loading_dialog);
        dialog.setCancelable(false);
        return dialog;
    }
}
