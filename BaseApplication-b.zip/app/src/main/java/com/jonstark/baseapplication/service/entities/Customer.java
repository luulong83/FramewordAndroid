package com.jonstark.baseapplication.service.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

@Entity
public class Customer implements Serializable{

    @NonNull
    @PrimaryKey
    @SerializedName("code")
    private String Id;
    @SerializedName("cusname")
    private String FullName;
    @SerializedName("taxcode")
    private String TaxCode;
    private String PhoneNumber;
    @SerializedName("address")
    private String Address;
    private String Email;

    //Vietnamese require field
    @SerializedName("ma_tuyen_cuoc")
    private String MaTuyenCuoc;
    @SerializedName("madt")
    private String MaDoiTuong;
    @SerializedName("ma_dot")
    private int MaDot;

    @NonNull
    public String getId() {
        return Id;
    }

    public void setId(@NonNull String id) {
        Id = id;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getTaxCode() {
        return TaxCode;
    }

    public void setTaxCode(String taxCode) {
        TaxCode = taxCode;
    }

    public String getMaTuyenCuoc() {
        return MaTuyenCuoc;
    }

    public void setMaTuyenCuoc(String maTuyenCuoc) {
        MaTuyenCuoc = maTuyenCuoc;
    }

    public String getMaDoiTuong() {
        return MaDoiTuong;
    }

    public void setMaDoiTuong(String maDoiTuong) {
        MaDoiTuong = maDoiTuong;
    }

    public int getMaDot() {
        return MaDot;
    }

    public void setMaDot(int maDot) {
        MaDot = maDot;
    }
}
