package com.jonstark.baseapplication.view.controller.activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Employee;
import com.jonstark.baseapplication.service.webservice.BaseApplicationWebservice;
import com.jonstark.baseapplication.utils.DialogUtils;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.edUsername)
    public EditText edUsername;
    @BindView(R.id.edPassword)
    public EditText edPassword;
    @BindView(R.id.cbxRemember)
    public CheckBox cbxRemember;
    @BindView(R.id.loginPage)
    public RelativeLayout loginPage;
    @Inject
    public BaseApplicationWebservice api;
    private SharedPreferences sharedPreferences;
    private Dialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        AndroidInjection.inject(this);
        ButterKnife.bind(this);
        loadLoginConfiguration();
        loadingDialog = DialogUtils.createLoadingDialog(this);
    }

    @OnClick({R.id.btnLogin})
    public void onButtonLoginClicked(){
        loadingDialog.show();
        api.employeeLogin(edUsername.getText().toString(), edPassword.getText().toString())
                .enqueue(new Callback<Employee>() {
                    @Override
                    public void onResponse(Call<Employee> call, Response<Employee> response) {
                        if(response.body() != null){
                            if(cbxRemember.isChecked()){
                                saveLoginConfiguration(response.body());
                            }else{
                                clearLoginConfiguration();
                            }
                            gotoMainActivity();
                        }else{
                            onFailure(call, null);
                        }
                        loadingDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<Employee> call, Throwable t) {
                        loadingDialog.dismiss();
                        Toast.makeText(LoginActivity.this, getResources().getString(R.string.login_fail_message), Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void gotoMainActivity(){
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    private void loadLoginConfiguration() {
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.share_preferences), MODE_PRIVATE);
        String userName = sharedPreferences.getString(getResources().getString(R.string.userNameKey), "");
        if (!userName.equals("")){
            final Dialog dialog = DialogUtils.createLoginConfirmDialog(this, userName);
            dialog.show();
        }
    }
    private void saveLoginConfiguration(Employee employee) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(getResources().getString(R.string.userNameKey), employee.getFullName());
        editor.putString(getResources().getString(R.string.userCodeKey), employee.getCode());
        editor.apply();
    }

    public void clearLoginConfiguration(){
        sharedPreferences.edit().remove(getResources().getString(R.string.userNameKey)).apply();
        sharedPreferences.edit().remove(getResources().getString(R.string.userCodeKey)).apply();
    }
}
