package com.jonstark.baseapplication.view.controller.fragment;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Batch;
import com.jonstark.baseapplication.service.entities.Customer;
import com.jonstark.baseapplication.view.adapter.ListCustomerAdapter;
import com.jonstark.baseapplication.view.controller.activity.CustomerDetailActivity;
import com.jonstark.baseapplication.view.controller.activity.MainActivity;
import com.jonstark.baseapplication.viewmodel.ViewModelFactory;
import com.jonstark.baseapplication.viewmodel.fragment.SharedViewModel;

import org.angmarch.views.NiceSpinner;
import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;

/**
 * A simple {@link Fragment} subclass.
 */
public class CustomerFragment extends Fragment {

    @BindView(R.id.rcCustomers)
    public RecyclerView rcCustomers;
    @BindView(R.id.spnBatch)
    public NiceSpinner spnBatch;
    @Inject
    public EventBus eventBus;
    @Inject
    public ViewModelFactory viewModelFactory;
    private SharedViewModel viewModel;
    private ListCustomerAdapter adapter;
    private List<Customer> customerList;
    private List<Batch> batchList;

    @Inject
    public CustomerFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //eventBus.register(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root =  inflater.inflate(R.layout.fragment_customer, container, false);
        ButterKnife.bind(this, root);
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);
        rcCustomers.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getContext()), DividerItemDecoration.VERTICAL));
        rcCustomers.setLayoutManager(new LinearLayoutManager(getContext()));
        viewModel = ViewModelProviders.of(Objects.requireNonNull(getActivity()), viewModelFactory).get(SharedViewModel.class);
    }

    @Override
    public void onStart() {
        super.onStart();
        initListBatchObserver();
        initListCustomerObserver();
    }

    private void initListCustomerObserver(){
        viewModel.getCustomers().observe(getActivity(), new Observer<List<Customer>>() {
            @Override
            public void onChanged(@Nullable List<Customer> customers) {
                customerList = customers;
                setupListCustomerAdapter(spnBatch.getSelectedIndex());
                rcCustomers.setAdapter(adapter);
            }
        });
    }
    private void initListBatchObserver(){
        viewModel.getBatches().observe(Objects.requireNonNull(getActivity()), new Observer<List<Batch>>() {
            @Override
            public void onChanged(@Nullable List<Batch> batches) {
                batchList = batches;
                final List<String> batchesName = new ArrayList<>();
                for(Batch batch : batchList){
                    batchesName.add(batch.getName());
                }
                spnBatch.attachDataSource(batchesName);
                spnBatch.addOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        spnBatch.setSelectedIndex(position);
                        setupListCustomerAdapter(spnBatch.getSelectedIndex());
                        rcCustomers.setAdapter(adapter);
                    }
                });
            }
        });
    }
    private void setupListCustomerAdapter(int batchIndex){
        final List<Customer> customers = new ArrayList<>();
        final int batch = batchList.get(batchIndex).getCode();
        for (Customer customer : customerList){
            if (customer.getMaDot() == batch){
                customers.add(customer);
            }
        }
        adapter = new ListCustomerAdapter(customers, getContext(), new ListCustomerAdapter.ListCustomerItemActionListener() {
            @Override
            public void onItemSelectedAtIndex(int index) {
                MainActivity mainActivity = (MainActivity) getActivity();
                final Customer customer = customers.get(index);
                Intent intent = new Intent(mainActivity, CustomerDetailActivity.class);
                intent.putExtra("customer", customer);
                Objects.requireNonNull(mainActivity).startActivity(intent);
            }
        });
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
