package com.jonstark.baseapplication.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Batch;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ListBatchAdapter extends RecyclerView.Adapter<ListBatchAdapter.ViewHolder>{
    private ListBatchItemActionListener callback;
    private List<Batch> batches;
    private Context context;

    public ListBatchAdapter(List<Batch> batches, Context context, ListBatchItemActionListener listBatchItemActionListener){
        this.callback = listBatchItemActionListener;
        this.batches = batches;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(parent.getContext()).inflate(R.layout.batch_list_item, parent, false);
        return new ViewHolder(root);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final int pos = position;
        Batch batch = batches.get(position);
        holder.tvBatchId.setText(context.getResources().getString(R.string.batch_code) + String.valueOf(batch.getCode()));
        holder.tvBatchName.setText(context.getResources().getString(R.string.name) +batch.getName());
        holder.btnDownLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callback.onDownloadButtonClickedAtPosition(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return batches.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.tvBatchId)
        public TextView tvBatchId;
        @BindView(R.id.tvBatchName)
        public TextView tvBatchName;
        @BindView(R.id.tvCustomerCount)
        public TextView tvCustomerCount;
        @BindView(R.id.tvInvoiceCount)
        public TextView tvInvoiceCount;
        @BindView(R.id.btnDownload)
        public Button btnDownLoad;
        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public interface ListBatchItemActionListener{
        void onDownloadButtonClickedAtPosition(int position);
    }
}
