package com.jonstark.architectureframework.appdata.entities;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "table_user")
public class User {
    @PrimaryKey(autoGenerate = true)
    private int ID;
    private String Name;
    private String Address;
    private String Phone;
    private String Email;
    private String UserName;
    private String Password;
    private Boolean Gender;

    public User(){}
    public User(String name, String address, String phone, String email, String userName, String password, Boolean gender) {
        Name = name;
        Address = address;
        Phone = phone;
        Email = email;
        UserName = userName;
        Password = password;
        Gender = gender;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public Boolean getGender() {
        return Gender;
    }

    public void setGender(Boolean gender) {
        Gender = gender;
    }
}
