package com.jonstark.architectureframework.di;
import android.app.Application;
import com.jonstark.architectureframework.MainApplication;
import com.jonstark.architectureframework.di.componentbuilder.ActivityBuilder;
import com.jonstark.architectureframework.di.componentbuilder.VModelBuilder;

import javax.inject.Singleton;
import dagger.BindsInstance;
import dagger.Component;
import dagger.android.AndroidInjectionModule;

@Singleton
@Component(modules = {MainAppModule.class, AndroidInjectionModule.class, ActivityBuilder.class, VModelBuilder.class})
public interface MainComponent {

    @Component.Builder
    interface Builder{
        @BindsInstance
        Builder application(Application application);
        MainComponent build();
    }

    void inject(MainApplication application);
}
