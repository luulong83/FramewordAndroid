package com.jonstark.architectureframework.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.jonstark.architectureframework.appdata.database.AppDatabase;
import com.jonstark.architectureframework.appdata.database.DaoObjects.UserDao;
import com.jonstark.architectureframework.appdata.entities.User;

import java.util.List;

import javax.inject.Inject;

import retrofit2.Retrofit;

public class LoginViewModel extends ViewModel {
    //User table data access object
    private final UserDao userDao;

    //List user
    private MediatorLiveData<List<User>> mUsers;
    

    @Inject
    public LoginViewModel(AppDatabase appDatabase) {


        this.userDao = appDatabase.getUserDao();
        this.mUsers = new MediatorLiveData<>();
        this.mUsers.setValue(null);
        LiveData<List<User>> result = userDao.getUsers();
        this.mUsers.addSource(result, new Observer<List<User>>() {
            @Override
            public void onChanged(@Nullable List<User> users) {
                mUsers.setValue(users);
            }
        });
    }
    public LiveData<List<User>> getUsers(){
        return mUsers;
    }
}
