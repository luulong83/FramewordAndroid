package com.jonstark.architectureframework.view.controller;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import com.jonstark.architectureframework.R;
import com.jonstark.architectureframework.appdata.entities.User;
import com.jonstark.architectureframework.view.adapter.ListUserAdapter;
import com.jonstark.architectureframework.viewmodel.LoginViewModel;
import com.jonstark.architectureframework.viewmodel.MainViewModel;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dagger.android.AndroidInjection;

public class LoginActivity extends AppCompatActivity {
    @BindView(R.id.btnLogin)
    public Button btnLogin;
    @BindView(R.id.edUsername)
    public EditText edUsername;
    @BindView(R.id.edPassword)
    public EditText edPassword;
    @Inject
    public ViewModelProvider.Factory factory;
    @Inject
    public LoginViewModel viewModel;
    private List<User> mUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Inject dependencies to this activity
        AndroidInjection.inject(this);

        //Inject view
        ButterKnife.bind(this);

        //Create viewModel
        viewModel = ViewModelProviders.of(this, this.factory).get(LoginViewModel.class);

        //Show list user in UI
        mUsers = new ArrayList<>();
        final Observer<List<User>> usersObserver = new Observer<List<User>>() {
            @Override
            public void onChanged(@Nullable List<User> users) {
                mUsers = users;
            }
        };
        viewModel.getUsers().observe(this, usersObserver);
    }

    @OnClick(R.id.btnLogin)
    public void onButtonLoginClicked(){
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}
