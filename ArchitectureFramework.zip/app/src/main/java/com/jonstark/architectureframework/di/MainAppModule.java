package com.jonstark.architectureframework.di;


import android.app.Application;
import android.arch.persistence.room.Room;
import android.content.Context;

import com.jonstark.architectureframework.appdata.database.AppDatabase;
import com.jonstark.architectureframework.viewmodel.LoginViewModel;
import com.jonstark.architectureframework.viewmodel.MainViewModel;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.internal.http.RetryAndFollowUpInterceptor;
import retrofit2.Retrofit;

@Module
public class MainAppModule {
    @Provides
    @Singleton
    public Context applicationContext(Application application){
        return application;
    }

    @Provides
    @Singleton
    public AppDatabase appDatabase(Application  application){
        return Room.databaseBuilder(application, AppDatabase.class, "main_app_database").build();
    }
    @Provides
    @Singleton
    public LoginViewModel loginViewModel(AppDatabase appDatabase){
        return new LoginViewModel(appDatabase);
    }
    @Provides
    @Singleton
    public MainViewModel mainViewModel(AppDatabase appDatabase){
        return new MainViewModel(appDatabase);
    }

    @Provides
    public Retrofit getRetrofit(){
        return null;
    }
}
