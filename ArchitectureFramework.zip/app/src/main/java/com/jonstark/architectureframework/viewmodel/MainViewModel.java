package com.jonstark.architectureframework.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.Nullable;

import com.jonstark.architectureframework.appdata.database.AppDatabase;
import com.jonstark.architectureframework.appdata.database.DaoObjects.UserDao;
import com.jonstark.architectureframework.appdata.entities.User;

import java.util.List;

import javax.inject.Inject;

public class MainViewModel extends ViewModel {
    //User table data access object
    private final UserDao userDao;

    //List user
    private MediatorLiveData<List<User>> mUsers;

    @Inject
    public MainViewModel(AppDatabase appDatabase) {


        this.userDao = appDatabase.getUserDao();
        this.mUsers = new MediatorLiveData<>();
        this.mUsers.setValue(null);
        LiveData<List<User>> result = userDao.getUsers();
        this.mUsers.addSource(result, new Observer<List<User>>() {
            @Override
            public void onChanged(@Nullable List<User> users) {
                mUsers.setValue(users);
            }
        });
    }
    public LiveData<List<User>> getUsers(){
        return mUsers;
    }
    public void addNewUser(User user){
        final User entity = user;
        new Thread(new Runnable() {
            @Override
            public void run() {
                userDao.insert(entity);
            }
        }).start();
    }
    public void updateUser(User user){

    }
}
