package com.jonstark.architectureframework.di.componentbuilder;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;

import com.jonstark.architectureframework.viewmodel.LoginViewModel;
import com.jonstark.architectureframework.viewmodel.MainViewModel;
import com.jonstark.architectureframework.viewmodel.VModelFactory;

import dagger.Binds;
import dagger.Module;
import dagger.multibindings.IntoMap;

@Module
public abstract class VModelBuilder {

    @Binds
    @IntoMap
    @ViewModelKey(LoginViewModel.class)
    abstract ViewModel bindLoginViewModel(LoginViewModel loginViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(MainViewModel.class)
    abstract ViewModel bindMainViewModel(MainViewModel loginViewModel);

    @Binds
    abstract ViewModelProvider.Factory bindViewModelFactory(VModelFactory modelFactory);
}
