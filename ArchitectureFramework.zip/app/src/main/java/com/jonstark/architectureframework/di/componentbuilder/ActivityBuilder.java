package com.jonstark.architectureframework.di.componentbuilder;


import com.jonstark.architectureframework.view.controller.LoginActivity;
import com.jonstark.architectureframework.view.controller.MainActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class ActivityBuilder {

    @ContributesAndroidInjector()
    abstract LoginActivity bindLoginActivity();

    @ContributesAndroidInjector()
    abstract MainActivity bindMainActivity();
}
