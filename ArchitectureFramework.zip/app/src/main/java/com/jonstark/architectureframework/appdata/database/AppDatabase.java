package com.jonstark.architectureframework.appdata.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.jonstark.architectureframework.appdata.database.DaoObjects.UserDao;
import com.jonstark.architectureframework.appdata.entities.User;

@Database(entities = {User.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    abstract public UserDao getUserDao();
}
