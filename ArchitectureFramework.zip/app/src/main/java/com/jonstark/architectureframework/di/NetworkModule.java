package com.jonstark.architectureframework.di;

public class NetworkModule {
}
