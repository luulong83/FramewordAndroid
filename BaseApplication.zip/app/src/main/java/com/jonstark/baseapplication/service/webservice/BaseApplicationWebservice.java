package com.jonstark.baseapplication.service.webservice;

import com.jonstark.baseapplication.service.entities.Employee;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BaseApplicationWebservice {
    @GET("admin/GetEmployee")
    Call<Employee> employeeLogin(@Query("userName") String userName, @Query("password") String password);
}
