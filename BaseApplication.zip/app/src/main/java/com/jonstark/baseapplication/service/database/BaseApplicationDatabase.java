package com.jonstark.baseapplication.service.database;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.jonstark.baseapplication.service.database.daoobject.CustomerDao;
import com.jonstark.baseapplication.service.database.daoobject.EmployeeDao;
import com.jonstark.baseapplication.service.entities.Employee;
import com.jonstark.baseapplication.service.entities.Customer;


@Database(entities = {
        Customer.class,
        Employee.class
}, version = 1, exportSchema = false)
public abstract class BaseApplicationDatabase extends RoomDatabase{
    abstract EmployeeDao employeeDao();
    abstract CustomerDao customerDao();
}
