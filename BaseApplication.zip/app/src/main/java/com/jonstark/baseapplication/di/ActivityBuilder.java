package com.jonstark.baseapplication.di;

import com.jonstark.baseapplication.di.subcomponent.MainActivityFragmentsBuilder;
import com.jonstark.baseapplication.di.subcomponent.MainActivityViewModelsBuilder;
import com.jonstark.baseapplication.view.controller.activity.MainActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class ActivityBuilder {
    @ContributesAndroidInjector(modules = {MainActivityFragmentsBuilder.class, MainActivityViewModelsBuilder.class})
    abstract MainActivity mainActivity();
}
