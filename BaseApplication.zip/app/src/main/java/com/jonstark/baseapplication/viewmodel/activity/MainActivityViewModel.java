package com.jonstark.baseapplication.viewmodel.activity;

import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.util.Log;

import javax.inject.Inject;

public class MainActivityViewModel extends ViewModel {
    private static final String TAG = "MAIN_AC VIEW MODEL";

    @Inject
    public MainActivityViewModel(Application application){

    }

    @Override
    protected void onCleared() {
        super.onCleared();
        Log.d(TAG, "cleared");
    }
}
