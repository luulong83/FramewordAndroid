package com.jonstark.baseapplication.service.database.daoobject;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;

import com.jonstark.baseapplication.service.entities.Employee;

import java.util.List;

@Dao
public interface EmployeeDao {

    @Query("select * from employee")
    LiveData<List<Employee>> getAllEmployee();

    @Query("select * from employee where Code= :code")
    LiveData<Employee> getEmployeeByCode(String code);
}
