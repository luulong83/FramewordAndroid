package com.jonstark.baseapplication;

import android.app.Activity;
import android.app.Application;

import com.jonstark.baseapplication.di.DaggerBaseApplicationComponent;

import javax.inject.Inject;

import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.HasActivityInjector;

public class BaseApplication extends Application implements HasActivityInjector{

    @Inject
    public DispatchingAndroidInjector<Activity> injector;
    @Override
    public void onCreate() {
        super.onCreate();
        DaggerBaseApplicationComponent.builder()
                .application(this)
                .build()
                .inject(this);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    public AndroidInjector<Activity> activityInjector() {
        return injector;
    }
}
