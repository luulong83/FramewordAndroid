package com.jonstark.baseapplication.service.database.daoobject;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;

import com.jonstark.baseapplication.service.entities.Customer;

import java.util.List;

@Dao
public interface CustomerDao {

    @Query("select * from customer")
    LiveData<List<Customer>> getAllCustomer();

    @Query("select * from customer where Id = :id")
    LiveData<Customer> getCustomerById(int id);
}
