package com.jonstark.baseapplication.view.controller.fragment;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jonstark.baseapplication.R;
import com.jonstark.baseapplication.service.entities.Employee;
import com.jonstark.baseapplication.service.webservice.BaseApplicationWebservice;
import com.jonstark.baseapplication.viewmodel.ViewModelFactory;
import com.jonstark.baseapplication.viewmodel.fragment.SharedViewModel;

import javax.inject.Inject;

import dagger.BindsInstance;
import dagger.android.support.AndroidSupportInjection;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FirstFragment extends Fragment {
    private static final String TAG = "FIRST FRAGMENT";
    private SharedViewModel viewModel;
    @Inject
    public ViewModelFactory viewModelFactory;

    @Inject
    public BaseApplicationWebservice webservice;

    @Inject
    public FirstFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "create");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AndroidSupportInjection.inject(this);
        viewModel = ViewModelProviders.of(getActivity(), viewModelFactory).get(SharedViewModel.class);
        webservice.employeeLogin("thanhhai", "thanhhai")
                .enqueue(new Callback<Employee>() {
                    @Override
                    public void onResponse(Call<Employee> call, Response<Employee> response) {
                        Log.d(TAG, response.body().toString());
                    }

                    @Override
                    public void onFailure(Call<Employee> call, Throwable t) {
                        Log.d(TAG, t.getMessage());
                    }
                });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "destroy");
    }
}
