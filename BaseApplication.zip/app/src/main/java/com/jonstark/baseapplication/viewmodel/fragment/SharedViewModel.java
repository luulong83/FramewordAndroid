package com.jonstark.baseapplication.viewmodel.fragment;
import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.util.Log;

import javax.inject.Inject;

public class SharedViewModel extends ViewModel {

    private static final String TAG = "SHARED VIEW MODEL";

    @Inject
    public SharedViewModel(Application application){

    }
    @Override
    protected void onCleared() {
        super.onCleared();
        Log.d(TAG, "cleared");
    }
}
